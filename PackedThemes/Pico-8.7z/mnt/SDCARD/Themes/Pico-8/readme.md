# PICO-8 by 369px

### Credits
- Font and Palette: Zep (Lexaloffle)
- Console Icons: found on kantOS, original icons: https://yspixel.jpn.org/icon/game/
- Every other asset: 369px (CC-BY-NC 4.0)

https://github.com/369px