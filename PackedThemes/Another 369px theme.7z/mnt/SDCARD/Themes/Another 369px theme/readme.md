# PICO-8 by 369px

### Credits
- Mai10 font by TypeAntoniolugb (https://online-fonts.com/designers/typeantoniolugb)
- Pico8 Font by Zep (https://lexaloffle.com)
- Console Icons: found on KantOS theme (original icons: https://yspixel.jpn.org/icon/game/)
- Every other asset: 369px (CC-BY-NC 4.0 - https://github.com/369px)

