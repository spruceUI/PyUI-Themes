# `Samurai` *by* `SkyWalker541`

Theme for sprig modded stock os


## Credits

**Font:** PixelIntv-OPxd:** by Oliver Lalan

**Icons:** By [Icons8](https://icons8.com/) - Cute Outline. Edited and modified by SkyWalker541

**Console Icons:** By Retroarch with additions by SkyWalker541

**Super Game Boy Icon:** By rodrigoomuller

**App Icons:** By [Icons8](https://icons8.com/) - Cute Outline. Edited and modified by SkyWalker541

**Pico8 Icon**:** By SkyWalker541

**change.wav File:** By Dragon Studio

**bgm.mp3 File:** By anars

**Sprites:** by Mattz Art

