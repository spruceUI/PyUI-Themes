An adaptation of the Sony 20th anniversary theme

Icons: Google Material Icons
https://github.com/google/material-design-icons

Game Icons: Pineapple.Graphics 
https://archive.org/details/@pineapple_graphics

The theme started off as a mod of ‘Cosy by KyleBing’ so there may be some leftover assets. 
Some assets have also been recoloured from ‘Spruce by tenlevels’

My personal display settings
Lum 11
Hue 9
Sat 16 
Con 10


